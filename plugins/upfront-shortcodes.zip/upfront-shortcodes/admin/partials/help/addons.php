<?php defined( 'ABSPATH' ) or exit; ?>

<ul>
	<li><a href="https://n3rds.work/shop/" target="_blank"><?php _e( 'Noch mehr Piestingtal.Source', 'upfront-shortcodes' ); ?></a></li>
</ul>
