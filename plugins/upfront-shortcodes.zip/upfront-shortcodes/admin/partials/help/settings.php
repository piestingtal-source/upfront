<?php defined( 'ABSPATH' ) or exit; ?>

<ul>
	<li><a href="https://nerds.work/docs-category/getting-started/" target="_blank"><?php _e( 'Getting started', 'upfront-shortcodes' ); ?></a></li>
	<li><a href="https://nerds.work/docs/plugin-settings-overview/" target="_blank"><?php _e( 'Plugin settings overview', 'upfront-shortcodes' ); ?></a></li>
	<li><a href="https://nerds.work/docs/how-to-use-custom-css-editor/" target="_blank"><?php _e( 'How to use Custom CSS editor', 'upfront-shortcodes' ); ?></a></li>
</ul>
