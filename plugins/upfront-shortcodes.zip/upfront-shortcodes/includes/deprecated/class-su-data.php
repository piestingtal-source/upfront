<?php

if ( ! class_exists( 'Su_Data' ) ) {

	/**
	 *
	 *
	 * @deprecated 1.0.0
	 */
	class Su_Data {

		/**
		 *
		 *
		 * @deprecated 1.0.0
		 */
		public static function icons() {
			return su_get_config( 'icons' );
		}

	}

}
